import unittest

from Prisoner import Prisoner


class TestConstructor(unittest.TestCase):

    def test_init_betray(self):
        prisoner_a = Prisoner(0)
        self.assertEqual(prisoner_a.get_strategy_name(), "Always Betray")

    def test_init_cooperate(self):
        prisoner_a = Prisoner(1)
        self.assertEqual(prisoner_a.get_strategy_name(), "Always Cooperate")

    def test_init_tit_for_tat(self):
        prisoner_a = Prisoner(2)
        self.assertEqual(prisoner_a.get_strategy_name(), "Tit for Tat")

    def test_init_tit_for_two_tats(self):
        prisoner_a = Prisoner(3)
        self.assertEqual(prisoner_a.get_strategy_name(), "Tit for Two Tats")

    def test_init_grim_trigger(self):
        prisoner_a = Prisoner(4)
        self.assertEqual(prisoner_a.get_strategy_name(), "Grim Trigger")


if __name__ == "__main__":
    unittest.main()
