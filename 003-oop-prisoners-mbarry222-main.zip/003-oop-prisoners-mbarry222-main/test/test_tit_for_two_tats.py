import unittest

from Prisoner import Prisoner


class TestTitForTwoTats(unittest.TestCase):

    def test_start_with_cooperate(self):
        prisoner_a = Prisoner(3)
        prisoner_b = Prisoner(3)
        prisoner_a.set_opponent(prisoner_b)
        prisoner_b.set_opponent(prisoner_a)
        result = prisoner_a.get_move(None)
        self.assertEqual('c', result)

    def test_cooperate_after_opponent_cooperates(self):
        prisoner_a = Prisoner(3)
        prisoner_b = Prisoner(3)
        prisoner_a.set_opponent(prisoner_b)
        prisoner_b.set_opponent(prisoner_a)
        result = prisoner_a.get_move('c')
        self.assertEqual('c', result)

    def test_cooperate_after_opponent_betrays(self):
        prisoner_a = Prisoner(3)
        prisoner_b = Prisoner(3)
        prisoner_a.set_opponent(prisoner_b)
        prisoner_b.set_opponent(prisoner_a)
        result = prisoner_a.get_move('b')
        self.assertEqual('c', result)

    def test_multiple_rounds(self):
        prisoner_a = Prisoner(3)
        prisoner_b = Prisoner(3)
        prisoner_a.set_opponent(prisoner_b)
        prisoner_b.set_opponent(prisoner_a)

        result = prisoner_a.get_move('b')
        self.assertEqual('c', result)

        result = prisoner_a.get_move('c')
        self.assertEqual('c', result)

        result = prisoner_a.get_move('b')
        self.assertEqual('c', result)

        result = prisoner_a.get_move('b')
        self.assertEqual('b', result)

        result = prisoner_a.get_move('c')
        self.assertEqual('c', result)

    def test_betray_after_opponent_betrays_twice(self):
        prisoner_a = Prisoner(3)
        prisoner_b = Prisoner(3)
        prisoner_a.set_opponent(prisoner_b)
        prisoner_b.set_opponent(prisoner_a)

        result = prisoner_a.get_move('b')
        self.assertEqual('c', result)

        result = prisoner_a.get_move('b')
        self.assertEqual('b', result)


if __name__ == "__main__":
    unittest.main()
