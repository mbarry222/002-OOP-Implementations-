import unittest

from Prisoner import Prisoner


class TestMemory(unittest.TestCase):

    def test_tit_for_two_tats_memory(self):
        # Tit-for-two-tats should only betray if betrayed twice by a specific player
        prisoner_a = Prisoner(3)
        prisoner_b = Prisoner(1)
        prisoner_c = Prisoner(0)

        prisoner_a.set_opponent(prisoner_b)

        result = prisoner_a.get_move('b')
        self.assertEqual('c', result)

        result = prisoner_a.get_move('b')
        self.assertEqual('b', result)

        prisoner_a.set_opponent(prisoner_c)

        result = prisoner_a.get_move('b')
        self.assertEqual('c', result)

        result = prisoner_a.get_move('b')
        self.assertEqual('b', result)

        result = prisoner_a.get_move('c')
        self.assertEqual('c', result)

        prisoner_a.set_opponent(prisoner_b)

        result = prisoner_a.get_move('b')
        self.assertEqual('b', result)

        result = prisoner_a.get_move('c')
        self.assertEqual('c', result)

    def test_grim_trigger_memory(self):
        # Grim trigger should only hold a grudge against the specific player(s) that betrayed it
        prisoner_a = Prisoner(4)
        prisoner_b = Prisoner(1)
        prisoner_c = Prisoner(0)

        prisoner_a.set_opponent(prisoner_b)

        result = prisoner_a.get_move('c')
        self.assertEqual('c', result)

        result = prisoner_a.get_move('b')
        self.assertEqual('b', result)

        prisoner_a.set_opponent(prisoner_c)

        result = prisoner_a.get_move('c')
        self.assertEqual('c', result)

        result = prisoner_a.get_move('b')
        self.assertEqual('b', result)

        result = prisoner_a.get_move('c')
        self.assertEqual('b', result)

        prisoner_a.set_opponent(prisoner_b)

        result = prisoner_a.get_move('b')
        self.assertEqual('b', result)

        result = prisoner_a.get_move('c')
        self.assertEqual('b', result)


if __name__ == "__main__":
    unittest.main()
