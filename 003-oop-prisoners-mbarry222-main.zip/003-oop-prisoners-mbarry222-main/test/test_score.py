import math
import unittest
from tournament import score
from Prisoner import Prisoner

class TestScore(unittest.TestCase):

    def test_both_cooperate(self):
        # If both player and computer cooperate, both should get 1 point.
        player_score, computer_score = score('c', 'c')
        self.assertEqual(1, player_score)
        self.assertEqual(1, computer_score)

    def test_player_cooperates_computer_betrays(self):
        # If the player cooperates and the computer betrays,
        # the player should get 3 points, and the computer should get 0 points.
        player_score, computer_score = score('c', 'b')
        self.assertEqual(player_score, 3)
        self.assertEqual(computer_score, 0)

    def test_player_betrays_computer_cooperates(self):
        # If the player betrays and the computer cooperates,
        # the player should get 0 points, and the computer should get 3 points.
        player_score, computer_score = score('b', 'c')
        self.assertEqual(player_score, 0)
        self.assertEqual(computer_score, 3)

    def test_both_betray(self):
        # If both player and computer betray, both should get 2 points.
        player_score, computer_score = score('b', 'b')
        self.assertEqual(player_score, 2)
        self.assertEqual(computer_score, 2)

    def test_set_scores(self):
        prisoner = Prisoner(0)
        self.assertEqual(0, prisoner.get_score())
        prisoner.set_score(10)
        self.assertEqual(10, prisoner.get_score())
        prisoner.set_score(100)
        self.assertEqual(100, prisoner.get_score())

    def test_set_scores_exceptions(self):
        prisoner = Prisoner(0)

        with self.assertRaises(TypeError):
            prisoner.set_score('TACO TOWN!!!')

        with self.assertRaises(TypeError):
            prisoner.set_score(math.pi)

        with self.assertRaises(ValueError):
            prisoner.set_score(-10)

    def test_get_scores(self):
        prisoner = Prisoner(0)
        prisoner.score = 10
        self.assertEqual(prisoner.get_score(), 10)

        prisoner.score = 100
        self.assertEqual(prisoner.get_score(), 100)


if __name__ == "__main__":
    unittest.main()
