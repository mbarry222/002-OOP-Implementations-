import unittest

from Prisoner import Prisoner


class TestGrimTrigger(unittest.TestCase):

    def test_start_with_cooperate(self):
        # When starting the game, the player should cooperate ('c').
        prisoner_a = Prisoner(4)
        prisoner_b = Prisoner(0)
        prisoner_a.set_opponent(prisoner_b)
        prisoner_b.set_opponent(prisoner_a)
        result = prisoner_a.get_move(None)
        self.assertEqual('c', result)

    def test_cooperate_after_opponent_cooperates(self):
        # If the opponent cooperates ('c') in the previous round,
        # the player should cooperate ('c') in the current round.
        prisoner_a = Prisoner(4)
        prisoner_b = Prisoner(0)

        prisoner_a.set_opponent(prisoner_b)
        prisoner_b.set_opponent(prisoner_a)
        result = prisoner_a.get_move('c')
        self.assertEqual('c', result)

    def test_betray_after_opponent_betrays(self):
        prisoner_a = Prisoner(4)
        prisoner_b = Prisoner(0)
        prisoner_a.set_opponent(prisoner_b)
        prisoner_b.set_opponent(prisoner_a)
        result = prisoner_a.get_move('b')
        self.assertEqual('b', result)

    def test_grudge(self):
        prisoner_a = Prisoner(4)
        prisoner_b = Prisoner(0)
        prisoner_a.set_opponent(prisoner_b)
        prisoner_b.set_opponent(prisoner_a)
        result = prisoner_a.get_move('b')
        self.assertEqual('b', result)

        result = prisoner_a.get_move('c')
        self.assertEqual('b', result)

    def test_grudge_forever(self):
        prisoner_a = Prisoner(4)
        prisoner_b = Prisoner(0)
        prisoner_a.set_opponent(prisoner_b)
        prisoner_b.set_opponent(prisoner_a)
        result = prisoner_a.get_move('c')
        self.assertEqual('c', result)

        result = prisoner_a.get_move('b')
        self.assertEqual('b', result)

        result = prisoner_a.get_move('c')
        self.assertEqual('b', result)

        result = prisoner_a.get_move('c')
        self.assertEqual('b', result)

        result = prisoner_a.get_move('c')
        self.assertEqual('b', result)


if __name__ == "__main__":
    unittest.main()
