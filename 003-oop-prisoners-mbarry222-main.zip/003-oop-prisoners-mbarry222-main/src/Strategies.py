class Prisoner:
    def __init__(self, strategy_number):
        self.strategy = strategy_number
        self.score = 0
        self.last_move = None  # Last move made by this prisoner
        self.opponent_last_move = None  # Last move made by the opponent
        self.grim_trigger_triggered = False  # Specific for the grim trigger strategy

    def reset(self):
        self.grim_trigger_triggered = False

    def get_move(self, last_choice):
        if self.strategy == 0:
            return self.always_betray()
        elif self.strategy == 1:
            return self.always_cooperate()
        elif self.strategy == 2:
            return self.tit_for_tat(last_choice)
        elif self.strategy == 3:
            return self.tit_for_two_tats()
        elif self.strategy == 4:
            return self.grim_trigger(last_choice)

    def always_betray(self):
        return 'b'

    def always_cooperate(self):
        return 'c'

    def tit_for_tat(self, last_choice):
        if last_choice is None:
            return 'c'
        return last_choice

    def tit_for_two_tats(self):
        # Assumes self.opponent_history is properly updated elsewhere
        if len(self.opponent_last_moves) >= 2 and self.opponent_last_moves[-1] == 'b' and self.opponent_last_moves[-2] == 'b':
            return 'b'
        return 'c'

    def grim_trigger(self, last_choice):
        if last_choice == 'b':
            self.grim_trigger_triggered = True
        return 'b' if self.grim_trigger_triggered else 'c'

    def get_score(self):
        return self.score

    def set_score(self, new_score):
        if not isinstance(new_score, int):
            raise TypeError("Score must be an integer")
        if new_score < 0:
            raise ValueError("Score cannot be negative")
        self.score = new_score

    def show(self):
        print(f"Strategy: {self.get_strategy_name()}, Score: {self.score}")

    def get_strategy_name(self):
        strategy_names = {
            0: "Always Betray",
            1: "Always Cooperate",
            2: "Tit-for-Tat",
            3: "Tit-for-Two-Tats",
            4: "Grim Trigger"
        }
        return strategy_names[self.strategy]