from Prisoner import Prisoner

def score(playerA_choice, playerB_choice):
    if playerA_choice == 'c' and playerB_choice == 'c':
        return 1, 1  # Both cooperate
    elif playerA_choice == 'c' and playerB_choice == 'b':
        return 0, 3  # Player A cooperates, Player B betrays
    elif playerA_choice == 'b' and playerB_choice == 'c':
        return 3, 0  # Player A betrays, Player B cooperates
    elif playerA_choice == 'b' and playerB_choice == 'b':
        return 2, 2  # Both betray

def play_round(playerA, playerB, player_choice):
    playerA_choice = player_choice if playerA.strategy is None else playerA.get_move(playerB.last_move)
    playerB_choice = playerB.get_move(playerA.last_move) if playerB.strategy is not None else player_choice

    score_A, score_B = score(playerA_choice, playerB_choice)

    # Update the scores
    playerA.set_score(playerA.get_score() + score_A)
    playerB.set_score(playerB.get_score() + score_B)

    return playerA_choice, playerB_choice, playerA.get_score(), playerB.get_score()

def get_player_choice():
    while True:
        choice = input("Will you ([c]ooperate or [b]etray)?: ").lower()
        if choice in ['c', 'b']:
            return choice
        else:
            print("Invalid input. Please enter 'c' for cooperate or 'b' for betray.")

def main():
    # Initialization of players
    human_player = Prisoner(None)
    computer_players = [Prisoner(i) for i in range(1)]

    print("Welcome to the Prisoner's Dilemma Tournament!")

    # Play the rounds
    for round_number in range(3):
        print(f"Round {round_number + 1}")
        player_choice = get_player_choice()

        for computer_player in computer_players:
            playerA_choice, playerB_choice, playerA_score, playerB_score = play_round(human_player, computer_player, player_choice)
            print(f"\nRound results:")
            print(f"Player A (Human or Strategy {human_player.get_strategy_name()}): Chose {playerA_choice}, Score: {playerA_score}")
            print(f"Player B (Strategy {computer_player.get_strategy_name()}): Chose {playerB_choice}, Score: {playerB_score}")

    # Display the final results
    print("\nFinal Scores and Strategies:")
    human_player.show()  # If human player's strategy and score should be displayed
    for index, computer_player in enumerate(computer_players):
        print(f"Computer Player {index + 1}: ", end='')
        computer_player.show()

    print("Thanks for participating in the tournament!")

if __name__ == "__main__":
    main()