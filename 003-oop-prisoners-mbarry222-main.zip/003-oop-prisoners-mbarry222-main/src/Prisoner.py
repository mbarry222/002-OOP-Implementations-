class Prisoner:
    def __init__(self, strategy_number):
        self.strategy = strategy_number
        self.score = 0
        self.last_move = 'c'
        self.opponent_history = []
        self.grim_trigger_triggered = False

    def reset(self):
        self.grim_trigger_triggered = False

    def get_move(self, last_move):
        if self.strategy == 0:
            return self.always_betray()
        elif self.strategy == 1:
            return self.always_cooperate()
        elif self.strategy == 2:
            return self.tit_for_tat(last_move)
        elif self.strategy == 3:
            return self.tit_for_two_tats()
        elif self.strategy == 4:
            return self.grim_trigger(last_move)

    def always_betray(self):
        return 'b'

    def always_cooperate(self):
        return 'c'

    def tit_for_tat(self, last_move):
        return last_move if last_move else 'c'

    def tit_for_two_tats(self):
        if len(self.opponent_history) >= 2 and self.opponent_history[-1] == 'b' and self.opponent_history[-2] == 'b':
            return 'b'
        else:
            return 'c'

    def grim_trigger(self, last_move):
        if last_move == 'b':
            self.grim_trigger_triggered = True
        return 'b' if self.grim_trigger_triggered else 'c'

    def get_strategy_name(self):
        strategy_names = {
            0: "Always Betray",
            1: "Always Cooperate",
            2: "Tit-for-Tat",
            3: "Tit-for-Two-Tats",
            4: "Grim Trigger"
        }
        return strategy_names.get(self.strategy, "Unknown Strategy")

    def set_score(self, new_score):
        self.score = new_score

    def get_score(self):
        return self.score

    def update_history(self, opponent_move):
        self.opponent_history.append(opponent_move)

    def show(self):
        print(f"Strategy: {self.get_strategy_name()}, Score: {self.score}")

# Example of using the class
if __name__ == "__main__":
    prisoner = Prisoner(2)
    opponent_last_move = 'c'
    prisoner_move = prisoner.get_move(opponent_last_move)
    print(f"Prisoner's move: {prisoner_move}")