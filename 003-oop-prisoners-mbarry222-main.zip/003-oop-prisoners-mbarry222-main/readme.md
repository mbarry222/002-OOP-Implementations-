# OOP Prisoner's Dilemma

In this homework assignment, you will implement a Python program that simulates the classic game known as the "Prisoner's Dilemma" in round-robin tournament between different players that each use different strategies. This assignment builds from the previous procedural tournament except it uses OOP principles to simplify the requirements for running a tournament instead of playing a simple 1v1 against a human opponent.

### Objectives:

1. Update the code for the three previous strategies for OOP principles. Translate the use of global variables accessible by functions into object variables accessible by methods in a class.
2. Implement two additional strategies as methods: Always Betray & Always Cooperate
3. Create five players and select one strategy for each to use while playing the game.
4. Implement code for each player to compete against the other four in an iterated prisoner's dilemma.
5. Each pair of players compete against each other over 100 rounds.
6. Each player will use the previous choice made by an opponent to determine its next move.
7. Display final scores and chosen strategy for each strategy. Optionally, declare the winner.
8. Extra Credit: each prisoner will have separate memory variables for each opponent.
9. Include comments and documentation in the code.
10. Submit two source files to GitHub and follow best coding practices.

**Assignment Requirements:**

**Step 1.** Design a Prisoner class. 

The class should include the previous three strategies (tit-for-tat, tit for two tats, grim trigger). It should also include two additional strategies (i.e., methods) that the computer can use in the Prisoner's Dilemma game. 

1. Always Betray:
   - This strategy will always betray another player regardless of the history of moves. 
2. Always Cooperate:
   - This strategy will always cooperate with another player regardless of the history of moves.

The class should include a constructor that takes the number of a strategy. That number represents what strategy that object will use to decide whether to betray or cooperate. The constructor should also initialize any other object variables necessary for the program to work correctly based on your design. The numbers for the strategies have been predetermined for you:

| Strategy           | Number |
|--------------------|--------|
| always_betray      | 0      |
| always_cooperate   | 1      |
| tit_for_tat        | 2      |
| tit_for_two_tats   | 3      |
| grim_trigger       | 4      |

The class should include implementations for the other strategies that you have designed for this course: "tit-for-tat", "tit-for-two-tats", and "grim trigger". As with the functions in the previous procedural approach to this assignment,  take the last choice made of a player as an argument. However, these _methods_ differ from the _functions_ that you previously designed in one critical way.  Instead of relying on global variables to store information about the previous moves of the opponent, they use object variables to determine whether to cooperate or betray. How these object variables are designed is up to you, but they will likely be very similar to your approach for the procedural global variable structure. 

As a reminder, the behavior for those strategies are:

1. Tit-for-Tat:
    - This [strategy](https://en.wikipedia.org/wiki/Tit_for_tat) starts with cooperation and then mimics the opponent's previous move. If the opponent cooperated in the previous round, it cooperates; if the opponent betrayed, it betrays. 
2. Grim Trigger:
   - The [Grim Trigger](https://en.wikipedia.org/wiki/Grim_trigger) strategy starts with cooperation and continues to cooperate until the opponent betrays. Once the opponent betrays, the grim trigger strategy holds a grudge and always chooses to betray for the rest of the game, never forgiving the betrayal.
3. Tit-for-Two-Tats:
   - [Tit-for-two-tats](https://en.wikipedia.org/wiki/Tit_for_tat#Tit_for_two_tats) starts with cooperation, and is similar to tit-for-tat, but it requires two consecutive betrayals from the opponent to betray. If the opponent cooperates, then it will start cooperating again until two consecutive betrayals are detected. 

The class should include a `get_move()` method. While each of the other methods deal with specific strategies, only the get_move() method should be called outside the class. Depending on which strategy has been assigned to this object, this method will call the correct strategy method and return the result.

> get_move is intended to make the tournament in Step 2 easier to write. You won't have to keep track of which object is using which strategy. Instead, you can call get_move on any of them, and the object will know which of the correct methods to use because the strategy was assigned when it was created. 

The class should include a `get_strategy_name()` method that returns a `str` with the strategy that is being used by that Prisoner object. If you're unclear what should be included, refer to the `test_constructor.py` file to see the outputs that we are looking for.

The class should include `get_score()` and `set_score()` methods. The get_score method should return the current number of years assigned to that Prisoner object. The set_score method should change the number of years to a certain number. If the set_score method is passed an argument that is not an instance of the int type, it should raise a TypeError. If the set_score method is passed an argument that is a negative number, it should raise a ValueError. 

The class includes a `set_opponent()` method. However, this should remain unimplemented and contain only the `pass` command unless you decide to attempt the extra credit (see below).  

Finally, the class should include a `show()` method that prints the name of the strategy used and score of the Prisoner object. Other information can be included at your discretion - there are no software tests for this method.

**Step 2.** Write a Python program in `tournament.py` with the following features:

The program should create five different Prisoner objects to represent the players in our tournament. Each player should be created to follow a different strategy.

Each player should compete against each of the other players in a single match. The match consists of 100 rounds. The contest is the iterated prisoner's dilemma. 

For each round, the program will get the choice of the two players by passing the last choice made by the other player. The first choice passed to the players will be 'None' in each match. Then, it will use getter and setter methods to determine the new years that will be added to the scores of those two players. 

To calculate the number of years added, the program will use a `score()` function similar to what was implemented in the previous program. 

> Why is `score()` in the program instead of the second file this time? Well, score takes two character arguments representing the choices made by two players and returns the number of years added to their sentence. If it were implemented as a method in the Prisoner class, it would need to be called on an object using dot notation, then passed two character arguments. It would be a bit clunky. Since it doesn't really belong to any single object as a behavior of that object, we move it to the tournament file. 

Still, the behavior for the score function is the same as in the previous assignment. Assign appropriate scores based on the outcomes of each round. Put the code for this into the `score()` function in the strategies.py file. The number of "years" added to the sentence must fit the following:

| Player Choice | Computer Choice | Player Score | Computer Score |
|---------------|-----------------|--------------|----------------|
| 'c'           | 'c'             | 1            | 1              |
| 'c'           | 'b'             | 3            | 0              |
| 'b'           | 'c'             | 0            | 3              |
| 'b'           | 'b'             | 2            | 2              |

Do NOT use the score function to calculate the additional years AND update the scores for the players. These should be calculated using the getter and setter methods for the score in the Prisoner class.

Finally, the program will use `show()` method on each Prisoner object to print the chosen strategy and score for all of them. There is no requirement to announce a winner, as it will be fairly obvious with just five players. But, if you would like, you may also calculate and announce the winning strategy.

## Extra Credit
If you can complete all of the above, you will find that you pass all tests except for those in `test_memory.py`. I do not recommend attempting the extra credit until you can do so. In fact, before you attempt this, go ahead and commit/push your Python program to the online repo, just in case you mess something up here and forget how to get back.

To earn the extra credit on this assignment, you need to correctly implement the `set_opponent()` method. What does this method do? Well, think of it this way - up to this point, each player sees all the moves of all four opponents as one combined history. If a `grim_trigger` player is betrayed by one opponent, then it will subsequently betray everyone else for every turn after that. This is a grudge *for life*. 

But, we'd like to add a little more realism to our prisoners. To do this, each Prisoner object needs to have a memory of the moves for EACH opponent, not just one big memory of ALL moves. If a `grim_trigger` player is betrayed by one opponent, then starts a new match with a new opponent, it should go back to starting with cooperate until the new opponent betrays them.  

How you accomplish this is up to you, but here are some general hints:
- If you are using a list to store the list of opponent moves, then you'll need a list for EACH opponent. If you're using a counter or boolean variables for the more complex strategies, then you'll need variables for each opponent. You're not allowed to manually create four different sets of records - your approach should work just as well if this were a tournament with five hundred prisoners instead of five.
- You'll need a method of storing and retrieving the memory for all opponents. However, you've chosen to store the individual memories, you'll need to put them into a collection. For hints on how to do this, take a look at how the early Bank uses lists and dictionaries to store data
- You are allowed to add other object variables to accomplish this, such as a list, dictionary, or prisoner ID number if you think it would help

Most of the work here will be accomplished in the initializer and the `set_opponent()` method. You _may_ need to modify your five strategy methods, but probably not. Regardless of your approach, all the original tests should still pass. You'll notice that the tests all use the set_opponent method. They should not stop working if it does more than `pass`. 

## Submission Guidelines:

Please commit/push your Python program in the two source files (Prisoner.py and tournament.py) along with any necessary comments and documentation. Ensure that your program is well-documented and follows best coding practices.

**Unit Tests**
Test files are provided for the functions and methods that you have been asked to write. Empty "method stubs" have been provided for you to complete. Do not change the names or parameters of the methods and functions - these are critical for the tests to let you know if a function working correctly. No `reset()` function is required this time - each object will be created with the starting variables necessary to track changes over the many iterations. 

Grading Criteria:
Please refer to Canvas for the grading rubric for this assignment. 